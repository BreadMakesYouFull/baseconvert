from baseconvert.baseconvert import BaseConverter
from baseconvert.baseconvert import base

import pkg_resources

__version__ = pkg_resources.require("baseconvert")[0].version
